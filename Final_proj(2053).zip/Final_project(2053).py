#!/usr/bin/env python
# coding: utf-8

# # FINAL PROJECT-BDM 2053 - Big Data Algorithms and Statistic 01

# Yashada Apte
# C0856941

# In[7]:


import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')


# In[8]:


data = pd.read_csv('laptop_price.csv', encoding = 'latin-1')
data.head()


# In[9]:


data.describe()


# In[72]:


data_corr = data.corr()
x_box, y_box = plt.subplots(figsize = (10,10))
sns.heatmap(data_corr, cmap = "crest", annot = True, linewidths = 0.5, ax = y_box)


# In[67]:


data_corr


# In[10]:


plt.figure(figsize=(10,6))
plt.title('Company vs Price', fontweight='bold')
sns.scatterplot(x='Company', y='Price', hue='Product', data=data)
sns.despine(top=True, right=True)
plt.xlabel('Companies', fontweight='bold')
plt.ylabel('Price', fontweight='bold')


# In[81]:


plt.figure(figsize=(10,6))
plt.title('Memory vs Price', fontweight='bold')
sns.scatterplot(x='Memory', y='Price', hue='Ram', data=data)
sns.despine(top=True, right=True)
plt.xlabel('Memory', fontweight='bold')
plt.ylabel('Price', fontweight='bold')


# In[12]:


laptops = list(data.Company.unique())
laptop_ids = dict(zip(laptops,[i for i in range(len((laptops)))]))
print(laptop_ids)


# In[13]:


Inches = list(data.Inches.unique())
Inches_ids = dict(zip(Inches,[i for i in range(len((Inches)))]))
print(Inches_ids)


# In[14]:


screen_resolution = data.ScreenResolution.unique()
resolution_ids = dict(zip(screen_resolution,[i for i in range(len((screen_resolution)))]))
print(resolution_ids)


# In[15]:


cpu = data.Cpu.unique()
cpu_ids = dict(zip(cpu,[i for i in range(len((cpu)))]))
print(cpu_ids)


# In[16]:


ram = data.Ram.unique()
ram_ids = dict(zip(ram,[i for i in range(len((ram)))]))
print(ram_ids)


# In[17]:


memory = data.Memory.unique()
memory_ids = dict(zip(memory,[i for i in range(len((memory)))]))
print(memory_ids)


# In[18]:


gpu = data.Gpu.unique()
gpu_ids = dict(zip(gpu,[i for i in range(len((gpu)))]))
print(gpu_ids)


# In[19]:


opsys = data.OpSys.unique()
opsys_ids = dict(zip(opsys,[i for i in range(len((opsys)))]))
print(opsys_ids)


# In[20]:


weight = data.Weight.unique()
weight_ids = dict(zip(weight,[i for i in range(len((weight)))]))
print(weight_ids)


# In[22]:


x = data.drop("Price", axis=1)### assigning y(dependent variable) and x(independent variable)
y = data["Price"]


# In[74]:


d1 = pd.DataFrame()

d1['Company'] = data['Company'].map(laptop_ids)
d1['Inches'] = data['Inches'].map(Inches_ids)
d1['ScreenResolution'] = data['ScreenResolution'].map(resolution_ids)
d1['Cpu'] = data['Cpu'].map(cpu_ids)
d1['Ram'] = data['Ram'].map(ram_ids)
d1['Memory'] = data['Memory'].map(memory_ids)
d1['Gpu'] = data['Gpu'].map(gpu_ids)
d1['OpSys'] = data['OpSys'].map(opsys_ids)
d1['Weight'] = data['Weight'].map(weight_ids)
d1['Price']=data['Price']

d1.head()


# In[77]:


plt.figure(figsize=(10,6))
plt.title('Company vs Price', fontweight='bold')
sns.scatterplot(x='Company', y='Price', hue='Gpu', data=d1)
sns.despine(top=True, right=True)
plt.xlabel('Companies', fontweight='bold')
plt.ylabel('Price', fontweight='bold')


# In[80]:


plt.figure(figsize=(10,6))
plt.title('Memory vs Price', fontweight='bold')
sns.scatterplot(x='Memory', y='Price', hue='Ram', data=d1)
sns.despine(top=True, right=True)
plt.xlabel('Memory', fontweight='bold')
plt.ylabel('Price', fontweight='bold')


# K-FOLD CROSS VALIDATION

# In[23]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y,
                                                    test_size=0.3,
                                                    random_state=42)


# In[24]:


from sklearn.model_selection import KFold

x = np.array([[1, 2], [3, 4], [1, 2], [3, 4]])
y = np.array([1, 2, 3, 4])
kf = KFold(n_splits=2)

for train_index, test_index in kf.split(x):
    print("TRAIN:", train_index, "TEST:", test_index)
    x_train, x_test = x[train_index], x[test_index]
    y_train, y_test = y[train_index], y[test_index]


# In[25]:


from sklearn.ensemble import RandomForestRegressor
rr = RandomForestRegressor()
rr.fit(x_train,y_train)
rr.score(x_test, y_test)


# In[26]:


from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(x_train,y_train)
lr.score(x_test,y_test)


# RANDOM FOREST REGRESSOR

# In[28]:


x = pd.DataFrame()

x['Company'] = data['Company'].map(laptop_ids)
x['Inches'] = data['Inches'].map(Inches_ids)
x['ScreenResolution'] = data['ScreenResolution'].map(resolution_ids)
x['Cpu'] = data['Cpu'].map(cpu_ids)
x['Ram'] = data['Ram'].map(ram_ids)
x['Memory'] = data['Memory'].map(memory_ids)
x['Gpu'] = data['Gpu'].map(gpu_ids)
x['OpSys'] = data['OpSys'].map(opsys_ids)
x['Weight'] = data['Weight'].map(weight_ids)
x['Price']=data['Price']

x.head()


# In[68]:


x.describe()


# In[79]:


x_corr = x.corr()
x_box, y_box = plt.subplots(figsize = (10,10))
sns.heatmap(x_corr, cmap = "crest", annot = True, linewidths = 0.5, ax = y_box)


# In[70]:


x_corr


# In[31]:


y = data.iloc[:,-1:]


# In[32]:


regressor = RandomForestRegressor(n_estimators = 200, random_state = 3)


# In[33]:


regressor.fit(x, y.values.ravel())


# In[34]:


regressor.score(x,y)


# LINEAR REGRESSION

# In[44]:


x = pd.DataFrame()

x['Company'] = data['Company'].map(laptop_ids)
x['Inches'] = data['Inches'].map(Inches_ids)
x['ScreenResolution'] = data['ScreenResolution'].map(resolution_ids)
x['Cpu'] = data['Cpu'].map(cpu_ids)
x['Ram'] = data['Ram'].map(ram_ids)
x['Memory'] = data['Memory'].map(memory_ids)
x['Gpu'] = data['Gpu'].map(gpu_ids)
x['OpSys'] = data['OpSys'].map(opsys_ids)
x['Weight'] = data['Weight'].map(weight_ids)
x['Price']=data['Price']

x.head()


# In[60]:


predictors = ['Price', 'memory']

X = x.drop(labels='Price' , axis=1)
Y = x['Price']


# In[61]:


X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size=0.3, random_state=99)


# In[62]:


from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(X_train, Y_train)
predict_y = lr.predict(X_test)
print(predict_y)


# In[64]:


from sklearn.metrics import  r2_score
coeff =lr.coef_
R_2 = r2_score(Y_test, predict_y)
MSE = mean_squared_error(Y_test, predict_y)
RMSE = np.sqrt(MSE)
print(R_2, MSE, RMSE)


# In[ ]:




